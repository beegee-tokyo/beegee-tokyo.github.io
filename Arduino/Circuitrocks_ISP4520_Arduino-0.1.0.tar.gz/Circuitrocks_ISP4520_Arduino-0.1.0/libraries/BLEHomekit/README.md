# Thanks

I want to thank a number of projects which made this possible:

1. https://github.com/aanon4/HomeKit - which provides reference implementation of homekit security on nrf5x
2. http://tweetnacl.cr.yp.to - which provides the compact eliptical curve implementations, as well as the sha512 hash.
3. https://github.com/ARMmbed/mbedtls - which provides the core multi-precission math routines used in the SRP implementation.
4. http://munacl.cryptojedi.org/ - which provides the ARM Cortex-M0 optimized Curve25519 implementation and fast multiply routines.



